// A broad genre catalog.

export const GENRE_CATALOG: string[] = [
  // --- Format / Origin ---
  "Manga",
  "Manhwa",
  "Manhua",
  "Webtoon",
  "Webcomic",
  "Cartoon",
  "Western",
  "Indie",
  "Doujinshi",
  "Fan Comic",
  "Web Novel",
  "Visual Novel",
  "4-Koma",
  "Oneshot",
  "Anthology",
  "Artbook",
  "Imageset",
  "Long Strip",
  "Full Color",
  "Fan-Colored",

  // --- Demographic ---
  "Shounen",
  "Shoujo",
  "Seinen",
  "Josei",
  "Kodomo",

  // --- Romance / Sexuality / Relationship ---
  "Romance",
  "Romantic Comedy",
  "Harem",
  "Reverse Harem",
  "Love Triangle",
  "Slow Burn",
  "Friends to Lovers",
  "Enemies to Lovers",
  "Marriage",
  "Contract Relationship",
  "Age Gap",
  // NOTE: GL/BL/Yaoi/Yuri, Omegaverse, etc are in Deviant Love. NSFW terms are in WarningTag.

  // --- Core Genres ---
  "Action",
  "Adventure",
  "Comedy",
  "Drama",
  "Fantasy",
  "Sci-Fi",
  "Horror",
  "Mystery",
  "Psychological",
  "Thriller",
  "Crime",
  "Detective",
  "Supernatural",
  "Historical",
  "Military",
  "War",
  "Politics",
  "Post-Apocalyptic",
  "Dystopian",
  "Utopian",
  "Slice of Life",
  "Tragedy",

  // --- Subgenres / Themes ---
  "School Life",
  "College Life",
  "Office Workers",
  "Workplace",
  "Medical",
  "Legal",
  "Cooking",
  "Food",
  "Fashion",
  "Music",
  "Idol",
  "Band",
  "Dance",
  "Art",
  "Photography",
  "Theater",

  // --- Sports / Games ---
  "Sports",
  "Martial Arts",
  "Boxing",
  "Wrestling",
  "Football",
  "Basketball",
  "Volleyball",
  "Baseball",
  "Tennis",
  "Badminton",
  "eSports",
  "Gaming",
  "VR",
  "Board Game",
  "Card Game",

  // --- Speculative / Powers ---
  "Superhero",
  "Superpowers",
  "Magic",
  "Witch",
  "Wizard",
  "Alchemy",
  "Cultivation",
  "Xianxia",
  "Xuanhuan",
  "Wuxia",
  "Mecha",
  "Kaiju",
  "Aliens",
  "Time Travel",
  "Parallel World",
  "Isekai",
  "Reincarnation",
  "Regression",
  "System",
  "Dungeon",
  "Tower",
  "Game Lit",
  "LitRPG",

  // --- Myth / Creatures ---
  "Vampire",
  "Werewolf",
  "Zombie",
  "Demon",
  "Angel",
  "Ghost",
  "Spirits",
  "Mythology",
  "Dragons",
  "Monsters",
  "Mermaid",

  // --- Character tropes ---
  "Anti-Hero",
  "Villainess",
  "Strong Female Lead",
  "Strong Male Lead",
  "Genius",
  "Overpowered",
  "Underdog",
  "Delinquents",
  "Yandere",
  "Tsundere",
  "Kuudere",
  "Dandere",
  "Otaku",
  "NEET",

  // --- Family / Life ---
  "Family",
  "Childcare",
  "Parenting",
  "Kids",
  "Sibling",
  "Found Family",
  "Coming of Age",
  "Friendship",

  // --- Dark / Sensitive ---
  "Violence",
  "Bullying",
  "Trauma",
  "Suicide",
  "Gambling",
  "Kidnapping",
  "Torture",
  // NOTE: Abuse, alcohol, drug use, gore, graphic violence, harassment, non-consensual, self-harm are WarningTag (NSFW).
  // NOTE: Incest is Deviant Love.

  // --- Settings ---
  "Urban",
  "Modern",
  "Contemporary",
  "Futuristic",
  "Space",
  "Cyberpunk",
  "Steampunk",
  "Dieselpunk",
  "Dieselpunk",
  "Gothic",
  "Dark Fantasy",
  "High Fantasy",
  "Low Fantasy",
  "Urban Fantasy",
  "Rural",
  "Countryside",

  // --- Historical periods ---
  "Ancient",
  "Medieval",
  "Renaissance",
  "Victorian",
  "Edo",
  "Meiji",
  "World War",
  "Modern History",

  // --- Culture / society ---
  "Royalty",
  "Nobility",
  "Politics",
  "Economy",
  "Business",
  "Showbiz",
  "Entertainment",

  // --- Mystery & crime details ---
  "Whodunit",
  "Forensics",
  "Heist",
  "Mafia",
  "Gang",
  "Assassin",
  "Espionage",

  // --- Romance tags people filter ---
  "Fluff",
  "Angst",
  "Heartwarming",
  "Bittersweet",
  "Love at First Sight",
  "Childhood Friends",
  "Second Chance",
  "Unrequited Love",

  // --- Gender / identity ---
  "Gender Bender",
  "Crossdressing",
  "Transgender",

  // NOTE: Omegaverse / A-B-O / BDSM / Fetish are NOT regular genres.

  // --- Aesthetics / vibes ---
  "Dark Academia",
  "Cozy",
  "Wholesome",
  "Melancholic",

  // --- Meta / production ---
  "Contest Winning",
  "Award Winning",
  "Adaptation",
  "Spin-off",
  "Sequel",
  "Prequel",
  "Remake",
  "Reboot",

  // --- Extra common filters from comic communities ---
  "Monsters Girls",
  "Monster Boy",
  "Beastmen",
  "Kemonomimi",
  "Catgirls",
  "Foxgirls",
  "Dragongirl",
  "Robot",
  "AI",
  "Virtual Idol",

  // --- Misc ---
  "Parody",
  "Satire",
  "Meta",
  "Philosophy",
  "Religion",
  "Education",
  "Travel",
  "Survival",
  "Apocalypse",
  "Natural Disaster",
  "Body Swap",
  "Body Horror",
  "Monster Horror",
  "Cosmic Horror",
];

export function uniqueGenreCatalog() {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const name of GENRE_CATALOG) {
    const n = String(name || "").trim();
    if (!n) continue;
    const key = n.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(n);
  }
  return out;
}
